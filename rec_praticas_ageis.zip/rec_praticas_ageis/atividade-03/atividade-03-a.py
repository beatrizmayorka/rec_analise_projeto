def contarCaracteres(frase):
    return len(frase)
