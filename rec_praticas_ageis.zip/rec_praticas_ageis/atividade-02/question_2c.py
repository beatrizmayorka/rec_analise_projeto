from string_invert import string_invert

def test_string_invert_string_mais_de_um_caractere():
    assert string_invert("hello") == "olleh"
