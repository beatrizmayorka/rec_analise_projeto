from string_invert import string_invert

def test_string_invert_string_um_caractere():
    assert string_invert("a") == "a"
