def string_invert(s):
    str_invertida = ""
    for c in reversed(s):
        str_invertida += c
    return str_invertida
